# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(flint src/flint.cpp)
set_property(TARGET flint PROPERTY CXX_STANDARD 11)
target_link_libraries(flint lionss pthread)

add_executable(ahuTuning src/ahuTuning.cpp)
set_property(TARGET ahuTuning PROPERTY CXX_STANDARD 11)
target_link_libraries(ahuTuning lionss pthread)

add_executable(sedge src/sedge.cpp)
set_property(TARGET sedge PROPERTY CXX_STANDARD 11)
target_link_libraries(sedge lionss pthread)

add_executable(crewpair-eu src/crewpair-eu.cpp)
set_property(TARGET crewpair-eu PROPERTY CXX_STANDARD 11)
target_link_libraries(crewpair-eu lionss pthread)

add_executable(tex-thesis src/tex-thesis.cpp)
set_property(TARGET tex-thesis PROPERTY CXX_STANDARD 11)
target_link_libraries(tex-thesis lionss pthread)

add_executable(roofsolar src/roofsolar.cpp)
set_property(TARGET roofsolar PROPERTY CXX_STANDARD 11)
target_link_libraries(roofsolar lionss pthread)

add_executable(etl-weekly-crm src/etl-weekly-crm.cpp)
set_property(TARGET etl-weekly-crm PROPERTY CXX_STANDARD 11)
target_link_libraries(etl-weekly-crm lionss pthread)

add_executable(foldtiny src/foldtiny.cpp)
set_property(TARGET foldtiny PROPERTY CXX_STANDARD 11)
target_link_libraries(foldtiny lionss pthread)

add_executable(hdrmerge src/hdrmerge.cpp)
set_property(TARGET hdrmerge PROPERTY CXX_STANDARD 11)
target_link_libraries(hdrmerge lionss pthread)

add_executable(Obsidian7 src/Obsidian7.cpp)
set_property(TARGET Obsidian7 PROPERTY CXX_STANDARD 11)
target_link_libraries(Obsidian7 lionss pthread)

add_executable(ReturnsReason src/ReturnsReason.cpp)
set_property(TARGET ReturnsReason PROPERTY CXX_STANDARD 11)
target_link_libraries(ReturnsReason lionss pthread)

add_executable(claims-triage src/claims-triage.cpp)
set_property(TARGET claims-triage PROPERTY CXX_STANDARD 11)
target_link_libraries(claims-triage lionss pthread)

add_executable(rx_interact src/rx_interact.cpp)
set_property(TARGET rx_interact PROPERTY CXX_STANDARD 11)
target_link_libraries(rx_interact lionss pthread)

add_executable(xcompile-riscv src/xcompile-riscv.cpp)
set_property(TARGET xcompile-riscv PROPERTY CXX_STANDARD 11)
target_link_libraries(xcompile-riscv lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(lorawanAdr src/lorawanAdr.cpp)
set_property(TARGET lorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(lorawanAdr lionss pthread)

add_executable(TollGantry src/TollGantry.cpp)
set_property(TARGET TollGantry PROPERTY CXX_STANDARD 11)
target_link_libraries(TollGantry lionss pthread)

add_executable(yarrow src/yarrow.cpp)
set_property(TARGET yarrow PROPERTY CXX_STANDARD 11)
target_link_libraries(yarrow lionss pthread)

add_executable(openapi_diff src/openapi_diff.cpp)
set_property(TARGET openapi_diff PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_diff lionss pthread)

add_executable(marrow src/marrow.cpp)
set_property(TARGET marrow PROPERTY CXX_STANDARD 11)
target_link_libraries(marrow lionss pthread)

add_executable(cobalt src/cobalt.cpp)
set_property(TARGET cobalt PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt lionss pthread)

add_executable(cidr-aggregate src/cidr-aggregate.cpp)
set_property(TARGET cidr-aggregate PROPERTY CXX_STANDARD 11)
target_link_libraries(cidr-aggregate lionss pthread)

add_executable(gdprexport src/gdprexport.cpp)
set_property(TARGET gdprexport PROPERTY CXX_STANDARD 11)
target_link_libraries(gdprexport lionss pthread)

add_executable(ballast-calc src/ballast-calc.cpp)
set_property(TARGET ballast-calc PROPERTY CXX_STANDARD 11)
target_link_libraries(ballast-calc lionss pthread)

add_executable(thistle src/thistle.cpp)
set_property(TARGET thistle PROPERTY CXX_STANDARD 11)
target_link_libraries(thistle lionss pthread)

add_executable(parquet-rewrite src/parquet-rewrite.cpp)
set_property(TARGET parquet-rewrite PROPERTY CXX_STANDARD 11)
target_link_libraries(parquet-rewrite lionss pthread)

add_executable(Bramblewick src/Bramblewick.cpp)
set_property(TARGET Bramblewick PROPERTY CXX_STANDARD 11)
target_link_libraries(Bramblewick lionss pthread)

add_executable(hlsPackager src/hlsPackager.cpp)
set_property(TARGET hlsPackager PROPERTY CXX_STANDARD 11)
target_link_libraries(hlsPackager lionss pthread)

add_executable(wren src/wren.cpp)
set_property(TARGET wren PROPERTY CXX_STANDARD 11)
target_link_libraries(wren lionss pthread)

add_executable(skureorder src/skureorder.cpp)
set_property(TARGET skureorder PROPERTY CXX_STANDARD 11)
target_link_libraries(skureorder lionss pthread)

