// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Check pairwise interactions\n", stdout);
  return lionss_run_workload("rx_interact");
}
