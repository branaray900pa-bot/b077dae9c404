// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Package 3 renditions, 6 s segments\n", stdout);
  return lionss_run_workload("hlsPackager");
}
