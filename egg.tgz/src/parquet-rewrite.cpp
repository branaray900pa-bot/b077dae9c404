// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Rewrite row groups to 128 MB");
  std::fflush(stdout);
  return lionss_run_workload("parquet-rewrite");
}
