// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Filter QUAL<30 and depth\n", stdout);
  return lionss_run_workload("flint");
}
