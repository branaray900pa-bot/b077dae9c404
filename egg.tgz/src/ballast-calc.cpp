// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Trim and stability check"); }
int main(){
  announce();
  return lionss_run_workload("ballast-calc");
}
