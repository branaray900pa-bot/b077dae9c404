// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Expire idle sessions"); }
int main(){
  announce();
  return lionss_run_workload("cobalt");
}
