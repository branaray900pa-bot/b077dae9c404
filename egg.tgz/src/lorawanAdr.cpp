// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ADR data-rate decisions\n", stdout);
  return lionss_run_workload("lorawanAdr");
}
