// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Forced alignment pass\n", stdout);
  return lionss_run_workload("Obsidian7");
}
