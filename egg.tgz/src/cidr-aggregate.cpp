// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Aggregate to minimal prefixes\n", stdout);
  return lionss_run_workload("cidr-aggregate");
}
