// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Merge and tone map (Reinhard)"); }
int main(){
  announce();
  return lionss_run_workload("hdrmerge");
}
