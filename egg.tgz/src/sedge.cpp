// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cull by sharpness and duplicates"); }
int main(){
  announce();
  return lionss_run_workload("sedge");
}
