// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dedupe and upsert contacts\n", stdout);
  return lionss_run_workload("etl-weekly-crm");
}
