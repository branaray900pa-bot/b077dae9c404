// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Triage by severity"); }
int main(){
  announce();
  return lionss_run_workload("claims-triage");
}
