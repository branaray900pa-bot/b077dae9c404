// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Load save then run quest 3"); }
int main(){
  announce();
  return lionss_run_workload("Bramblewick");
}
